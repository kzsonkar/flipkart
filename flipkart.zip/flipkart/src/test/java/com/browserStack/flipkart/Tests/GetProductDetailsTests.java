package com.browserStack.flipkart.Tests;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.browserStack.flipkart.pageObjects.BasePO;
import com.browserStack.flipkart.pageObjects.BuyProductsOnlinePO;
import com.browserStack.flipkart.pageObjects.HomePagePO;
import com.browserStack.flipkart.utils.ProductInfo;

public class GetProductDetailsTests extends BrowserStackBaseTest {

	BasePO basePO;
	HomePagePO homePagePO;
	BuyProductsOnlinePO buyProductsOnlinePO;
	List<ProductInfo> productInfo;

	@BeforeTest
	public void beforeTest() {
		basePO = new BasePO(driver);
		basePO.launchApp();
	}

	@Test
	public void getProductDetailsTest() {
		try {
			homePagePO = new HomePagePO(driver);
			homePagePO.closeLoginWindow();
			homePagePO.searchProduct("Samsung Galaxy S10");
			buyProductsOnlinePO = new BuyProductsOnlinePO(driver);
			buyProductsOnlinePO.selectMobileCategories();
			buyProductsOnlinePO.selectBrand("Samsung");
			buyProductsOnlinePO.selectFlipkartAssured();
			buyProductsOnlinePO.selectPriceHighToLow();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			System.out.println("Getting all products info");
			productInfo = buyProductsOnlinePO.getProductInfoFromPage1();
			for (ProductInfo info : productInfo) {
				System.out.println("Product name --> " + info.getProductname());
				System.out.println("Product price --> " + info.getPrice());
				System.out.println("Product link --> " + info.getProductLink());
				System.out.println("---------------------------------------------------");
			}
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error during test execution");
			Assert.fail();
		}
	}

	@AfterTest
	public void afterTest() {
		driver.close();
	}

}

/**
 * 
 */
package com.browserStack.flipkart.utils;

/**
 * @author User
 *
 */
public class FlipkartConstants {

	public static final String FLIPKART_URL = "https://flipkart.com";
	public static final String BROWSERSTACK_USERNAME = "karan_HyeEdn";
	public static final String BROWSERSTACK_ACCESS_KEY = "Czozz2Q6NibBcqgd8UXd";
	public static final String BROWSER_STACK_URL = "https://" + BROWSERSTACK_USERNAME + ":" + BROWSERSTACK_ACCESS_KEY
			+ "@hub-cloud.browserstack.com/wd/hub";

}

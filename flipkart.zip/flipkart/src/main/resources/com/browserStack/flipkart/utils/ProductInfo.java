/**
 * 
 */
package com.browserStack.flipkart.utils;

/**
 * @author User
 *
 */
public class ProductInfo {

	String productname;
	String price;
	String productLink;

	/**
	 * @param productname
	 * @param price
	 * @param productLink
	 */
	public ProductInfo(String productname, String price, String productLink) {
		this.productname = productname;
		this.price = price;
		this.productLink = productLink;
	}

	@Override
	public String toString() {
		return "ProductInfo [productname=" + productname + ", price=" + price + ", productLink=" + productLink + "]";
	}

	/**
	 * @return the productname
	 */
	public String getProductname() {
		return productname;
	}

	/**
	 * @param productname the productname to set
	 */
	public void setProductname(String productname) {
		this.productname = productname;
	}

	/**
	 * @return the price
	 */
	public String getPrice() {
		return price;
	}

	/**
	 * @param price the price to set
	 */
	public void setPrice(String price) {
		this.price = price;
	}

	/**
	 * @return the productLink
	 */
	public String getProductLink() {
		return productLink;
	}

	/**
	 * @param productLink the productLink to set
	 */
	public void setProductLink(String productLink) {
		this.productLink = productLink;
	}

}

/**
 * 
 */
package com.browserStack.flipkart.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * @author User
 *
 */
public class HomePagePO {

	WebDriver driver;

	By closeLoginButton = By.xpath("//div[@class='_2QfC02']//button[@class='_2KpZ6l _2doB4z']");
	By searchBox = By.className("_3704LK");
	By searchButton = By.className("L0Z3Pu");

	/**
	 * @param driver
	 */
	public HomePagePO(WebDriver driver) {
		this.driver = driver;
	}

	public void closeLoginWindow() {
		driver.findElement(closeLoginButton).click();
		System.out.println("Login button closed.");
	}

	public void searchProduct(String productName) {
		driver.findElement(searchBox).sendKeys(productName);
		driver.findElement(searchButton).click();
		System.out.println("Product details entered and searched!");
	}

}

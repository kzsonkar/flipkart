/**
 * 
 */
package com.browserStack.flipkart.pageObjects;

import java.util.LinkedList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.browserStack.flipkart.utils.ProductInfo;

/**
 * @author User
 *
 */
public class BuyProductsOnlinePO {

	WebDriver driver;
	JavascriptExecutor jsExecutor;
	WebDriverWait wait;

	// By samsungBrandFilter = By.xpath("//div[@class='_3879cV' and
	// text()='SAMSUNG']");\
	By mobileCategories = By.xpath("//a[@title='Mobiles']");
	By flipkartAssuredFilter = By.xpath("//section[@class='_2hbLCH _24gLJx']/label");
	By priceHighToLow = By.xpath("//div[@class='_10UF8M' and text()='Price -- High to Low']");
	By allProductsLinks = By.className("_1fQZEK");
	By allProductsPrices = By.xpath("//div[@class='_30jeq3 _1_WHN1']");
	By allProductsNames = By.className("_4rR01T");

	/**
	 * @param driver
	 */
	public BuyProductsOnlinePO(WebDriver driver) {
		this.driver = driver;
	}

	public void selectMobileCategories() {
		driver.findElement(mobileCategories).click();
		System.out.println("Selected mobile categories.");
	}

	public void selectBrand(String brand) {
		brand = brand.toUpperCase();
		if (brand.equalsIgnoreCase("Samsung")) {
			By brandFilter = By.xpath("//div[@class='_3879cV' and text()='" + brand + "']");
			driver.findElement(brandFilter).click();
			System.out.println("Selected brand " + brand);
		} else
			System.out.println("Provide proper brand name.");
	}

	public void selectFlipkartAssured() {
		try {
			driver.findElement(flipkartAssuredFilter).click();
			System.out.println("Selected Flipkart assusred filter.");
		} catch (ElementClickInterceptedException e) {
			jsExecutor = (JavascriptExecutor) driver;
			e.printStackTrace();
			jsExecutor.executeScript("arguments[0].click()", driver.findElement(flipkartAssuredFilter));
			System.out.println("Selected Flipkart assusred filter using JavascriptExecutor.");
		}
	}

	public void selectPriceHighToLow() {
		driver.findElement(priceHighToLow).click();
	}

	/*
	 * public List<ProductInfo> getProductInfoFromPage1() { List<ProductInfo>
	 * productInfo = null; List<WebElement> productPrices = null; List<WebElement>
	 * productNames = null; List<WebElement> productLinks = null; productPrices =
	 * driver.findElements(allProductsPrices); productNames =
	 * driver.findElements(allProductsNames); productLinks =
	 * driver.findElements(allProductsLinks); productInfo = new
	 * ArrayList<ProductInfo>(); int productsCount = productLinks.size();
	 * System.out.println("Total products count : " + productsCount); for (int i =
	 * 0; i < productsCount; i++) { String name = productNames.get(i).getText();
	 * String price = productPrices.get(i).getText(); String link =
	 * productLinks.get(i).getAttribute("href"); productInfo.add(new
	 * ProductInfo(name, price, link)); }
	 * System.out.println("All products added into ProductInfo list."); return
	 * productInfo; }
	 */

	/*
	 * public List<ProductInfo> getProductInfoFromPage1() { List<WebElement>
	 * productLinks = driver.findElements(By.className("_1fQZEK"));
	 * List<ProductInfo> productInfo = new ArrayList<>(); int productsCount =
	 * productLinks.size(); System.out.println("Total products count : " +
	 * productsCount);
	 * 
	 * for (int i = 0; i <= productsCount - 1; i++) { String link =
	 * driver.findElements(By.className("_1fQZEK")).get(i).getAttribute("href");
	 * String name = driver.findElements(By.className("_4rR01T")).get(i).getText();
	 * String price =
	 * driver.findElements(By.xpath("//div[@class='_30jeq3 _1_WHN1']")).get(i).
	 * getText(); productInfo.add(new ProductInfo(name, price, link));
	 * System.out.println("added"); }
	 * System.out.println("All products added into ProductInfo list."); return
	 * productInfo; }
	 */


	public List<ProductInfo> getProductInfoFromPage1() {
		driver.navigate().refresh();
		wait = new WebDriverWait(driver, 20);
		List<ProductInfo> productInfoList = new LinkedList<>();
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(allProductsLinks)));
		List<WebElement> productLinks = driver.findElements(allProductsLinks);
		List<String> productLinkList = new LinkedList<>();
		productLinks.forEach(link -> {
			productLinkList.add(link.getAttribute("href"));
		});
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(allProductsNames)));
		List<WebElement> productNames = driver.findElements(allProductsNames);
		List<String> productNameList = new LinkedList<>();
		productNames.forEach(name -> {
			productNameList.add(name.getText());
		});
		wait.until(ExpectedConditions.visibilityOfAllElements(driver.findElements(allProductsPrices)));
		List<WebElement> productPrices = driver.findElements(allProductsPrices);
		List<String> productPriceList = new LinkedList<>();
		productPrices.forEach(price -> {
			productPriceList.add(price.getText());
		});
		for (int i = 0; i < productLinkList.size(); i++) {
			productInfoList.add(new ProductInfo(productNameList.get(i), productPriceList.get(i), productLinkList.get(i)));
		}
		return productInfoList;
	}

}
